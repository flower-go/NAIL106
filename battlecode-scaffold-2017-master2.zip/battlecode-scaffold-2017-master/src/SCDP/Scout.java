package SCDP;

public class Scout {
    public static void runScout(){
        //TODO code here
    }
}
