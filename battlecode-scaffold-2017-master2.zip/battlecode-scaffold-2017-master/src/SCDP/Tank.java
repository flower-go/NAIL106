package SCDP;

public class Tank {
    public static void runTank(){
        //TODO code here
    }
}
