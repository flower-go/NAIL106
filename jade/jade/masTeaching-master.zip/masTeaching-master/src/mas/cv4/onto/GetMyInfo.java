package mas.cv4.onto;

import jade.content.AgentAction;

/**
 * Created by Martin Pilat on 13.2.14.
 *
 * Request to send the information about the agent (send info on the sender of the message)
 */
public class GetMyInfo implements AgentAction {

}
