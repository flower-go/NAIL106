package mas.cv4.onto;

import jade.content.AgentAction;

/**
 * Created by Martin Pilat on 16.4.14.
 *
 * Information for the agents to start trading
 */
public class StartTrading implements AgentAction {
}
