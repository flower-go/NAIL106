package mas.cv3.onto;

import jade.content.AgentAction;
import jade.content.onto.annotations.AggregateResult;

import java.util.ArrayList;

/**
 * Created by marti_000 on 8.4.14.
 */
@AggregateResult(type = BookInfo.class)
public class GetBookList implements AgentAction {
}
